using UnityEngine;

/// A placed object (car, tree, keys...). Its pivot is the model's base center.
public class Prop : MonoBehaviour
{
    public string entryName;
}
