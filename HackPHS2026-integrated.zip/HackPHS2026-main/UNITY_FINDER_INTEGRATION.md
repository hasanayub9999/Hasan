# Human Finder + Object Finder integration

The Flight Lab now has **Object Finder** and **Human Finder** selectors.

## What is wired up

- **Object Finder** uses the current browser-based 3D preview unless the Unity WebGL build exists at `drone-city/Build/drone-city.loader.js`. If that build exists, the portal embeds `drone-city/index.html`.
- **Human Finder** looks for a WebGL build at `building-search/Build/building-search.loader.js` and `building-search/index.html`. Until that build is exported, the portal shows an honest setup notice rather than a blank panel.
- Ali's Unity source code remains in the `Unity/` (drone/object navigation) and `Building/` (fire building / trapped people / search drones) projects.

## Finish the Unity integration

### Object Finder
1. Open the `Unity/` project in Unity Hub.
2. Open **Drone City** and use **Drone Sim → Build Web (Drone City)** if that menu is available.
3. The included `WebBuild.cs` script targets the `drone-city/` folder. After a successful build, confirm that `drone-city/Build/drone-city.loader.js`, `.data`, `.framework.js`, and `.wasm` exist.
4. Test `drone-city/index.html` through a web server / GitHub Pages.

### Human Finder
1. Open the `Building/` project in Unity Hub.
2. Open **Drone 2 → Drone Search Demo** to generate/open the search scene, or use `Assets/Scenes/DroneSearchDemo.unity`.
3. Add that scene to the WebGL build scene list and build for WebGL.
4. Put the generated WebGL output in `building-search/`. The expected output includes `building-search/index.html` and `building-search/Build/building-search.loader.js` plus the matching `.data`, `.framework.js`, and `.wasm` files. Keep the filenames consistent with the generated `index.html`.
5. Reload `portal.html`. The Human Finder selector will detect the build and display it in the Flight Lab.

## Important

The uploaded repository includes Unity project source but **does not include either compiled WebGL build**. This edit connects the portal to those builds when present; it cannot compile Unity projects itself. Camera/LiDAR/human detection should be described according to the features actually implemented and tested, not assumed from the scene visuals.
