(() => {
  const choices = [...document.querySelectorAll('[data-finder]')];
  const mount = document.getElementById('mount');
  const unityFrame = document.getElementById('unityFrame');
  const humanNotice = document.getElementById('humanBuildNotice');
  const status = document.getElementById('finderStatus');
  const viewTitle = document.querySelector('.viewtop > span');
  const missionTitle = document.querySelector('.target strong');
  const targetLabel = document.querySelector('.target small');
  let activeFinder = 'object';
  let checks = {};

  async function buildExists(path) {
    if (path in checks) return checks[path];
    try {
      const response = await fetch(path, { method: 'HEAD', cache: 'no-store' });
      checks[path] = response.ok;
    } catch (_) {
      checks[path] = false;
    }
    return checks[path];
  }

  function setChrome(mode) {
    const human = mode === 'human';
    if (viewTitle) viewTitle.innerHTML = `<i></i> ${human ? 'HUMAN FINDER' : 'OBJECT FINDER'} <em>/</em> ${human ? 'FIRE BUILDING' : 'OBJECT SEARCH'}`;
    if (missionTitle) missionTitle.textContent = human ? 'Human Search Zone' : 'Object Search Zone';
    if (targetLabel) targetLabel.textContent = human ? 'SEARCH AREA' : 'SEARCH TARGET';
    choices.forEach(button => {
      const selected = button.dataset.finder === mode;
      button.classList.toggle('active', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  async function switchFinder(mode) {
    activeFinder = mode;
    setChrome(mode);
    unityFrame.hidden = true;
    humanNotice.hidden = true;
    mount.style.visibility = mode === 'object' ? 'visible' : 'hidden';

    if (mode === 'object') {
      const available = await buildExists('drone-city/Build/drone-city.loader.js');
      if (activeFinder !== mode) return;
      if (available) {
        unityFrame.src = 'drone-city/index.html';
        unityFrame.title = 'Unity Object Finder simulation';
        unityFrame.hidden = false;
        status.textContent = 'Object Finder · Unity WebGL simulation';
      } else {
        status.textContent = 'Object Finder · browser preview active; Unity WebGL build not found';
      }
      return;
    }

    const available = await buildExists('building-search/Build/building-search.loader.js');
    if (activeFinder !== mode) return;
    if (available && await buildExists('building-search/index.html')) {
      unityFrame.src = 'building-search/index.html';
      unityFrame.title = 'Unity Human Finder fire-building simulation';
      unityFrame.hidden = false;
      status.textContent = 'Human Finder · Unity WebGL simulation';
    } else {
      humanNotice.hidden = false;
      status.textContent = 'Human Finder · Unity source found; WebGL build still needs exporting';
    }
  }

  choices.forEach(button => button.addEventListener('click', () => switchFinder(button.dataset.finder)));
  switchFinder('object');
})();